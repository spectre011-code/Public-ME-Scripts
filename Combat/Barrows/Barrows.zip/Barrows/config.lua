--Config file for Spectre's Barrows Brothers Killer for script manager

SM:AddTab("Main")
SM:NumberInput("Stop after time (min)", "MaxTime", 1440, 1, 1440)


